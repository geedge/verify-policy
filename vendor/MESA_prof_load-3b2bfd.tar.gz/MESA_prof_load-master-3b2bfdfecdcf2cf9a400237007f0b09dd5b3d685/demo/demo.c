#include "MESA_prof_load.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
	short int g_port;
	unsigned int user_amount;
	int ret, i;
	//unsigned int ips[10]={0};
	char path[256]={0};
	unsigned int out[12];

	if((ret=MESA_load_profile_uint_range("config.ini","CONFIG","ports",12, out))<0)
		return -1;
	else
	{
		printf("read %d ports:\n",ret);
		for(i = 0; i < ret; i++)
			printf("\tport[%d]:%d\n",i, out[i]);
	}

	if(MESA_load_profile_short_nodef("config.ini","CONFIG","port",&g_port)<0)
		return -1;
	else
		printf("g_port:%d\n",g_port);
	if((ret = MESA_load_profile_short_def("config.ini","CONFIG","port",&g_port,999))<0)
		printf("g_port:%d,ret:%d\n",g_port,ret);
	
	if(MESA_load_profile_uint_nodef("config.ini","CONFIG","users",&user_amount)<0)
		return -1;
	else
		printf("user_amount:%u\n",user_amount);
	MESA_load_profile_uint_def("config.ini","CONFIG","users",&user_amount,0);
	printf("user_amount:%u\n",user_amount);
	if((ret=MESA_load_profile_string_nodef("config.ini","CONFIG","log_path",path,256))<0)
		return -1;
	else
		printf("path:%s,ret:%d\n",path,ret);
	memset(path,0,256);
	if((ret=MESA_load_profile_string_def("config.ini","CONFIG","log_path",path,256,"./logger"))>0)
		printf("path:%s,ret:%d\n",path,ret);

#if 0
	if((ret=MESA_load_profile_ipset("config.ini","CONFIG","ips",10,ips))>0)
		printf("ret:%d\n",ret);
	
	if((ret = MESA_write_profile_int("./config.ini","CONFIG","port",12345))<0)
	{
		printf("write int failed!!\n");
	}
	if((ret = MESA_write_profile_string("./config.ini","CONFIG","log_path","/home/taojianxi/"))<0)
	{
		printf("write int failed!!\n");
	}
	if((ret = MESA_write_profile_float("./config.ini","CONFIG","salaries",8888.8))<0)
	{
		printf("write int failed!!\n");
	}
	if((ret = MESA_write_profile_string("./config.ini","DB_CONFIG","username","ashi"))<0)
	{
		printf("write int failed!!\n");
	}
	if((ret = MESA_write_profile_int("./config.ini","DB_CONFIG","maxpasswd_len",4))<0)
	{
		printf("write int failed!!\n");
	}
	if((ret = MESA_write_profile_float("./config.ini","DB_CONFIG","salaries",12983.10))<0)
	{
		printf("write int failed!!\n");
	}

#endif
	return 0;
}
