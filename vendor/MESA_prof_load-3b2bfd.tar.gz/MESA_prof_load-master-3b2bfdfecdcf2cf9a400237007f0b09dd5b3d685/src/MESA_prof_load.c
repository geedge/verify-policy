// loadprof.c
//
// general routines to read in profile
//
// CREATED by Song Xinbo, 2003-06-23
// MODIFIED by tjx,2012-06-09
// MODIFIED by tjx, 2013-05-23:
//	add the write function
//	strcpy and strncpy are replaced with memmove,because the strcpy and strncpy is not safe, they is not able to be used in overlap memory
// MODIFUED by tjx,2013-06-19
//	fixed the bug that get error string when nothing behind the '=' int the fucntion seek_key
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include "MESA_prof_load.h"

#ifdef WIN32
#define strncasecmp(x,y,z) memicmp(x,y,z)
#endif
#ifdef WIN32
#define LINE_BREAK_TAG	"\r\n"
#else
#define LINE_BREAK_TAG	"\n"
#endif

#define MAX_PROF_LINE	4096	/* MAX bytes in a single line */
#define MAX_IP_SIZE 	16      /* MAX bytes in a single ip string*/
#define COMMENT_CHAR	'#'	/* comments line prefix */
#define SECTION_PRE	'['	/* section name prefix */
#define SECTION_POST	']'	/* section name postfix */
#define VALUE_SET	'='	/* set key value operator */
#define HYPHEN 		'-'
#define TYPE_INT	1
#define TYPE_FLOAT	2
#define TYPE_STRING	3

int PROF_LOAD_VERSION_20161130 = 1;
//convert string to int
//return :
// 	0,success
// 	-1,failed
static int str2int(const char *str, //[IN]  the string need to convert
	    int  *val)//[OUT] convert result
{
	int  	tmpval;
	char 	*tmp_str=(char*)str;
	char 	check_str[16]={0};
	if(tmp_str==NULL||strlen(tmp_str)<=0||strlen(tmp_str)>11)
		return -1;
	tmpval=atoi(tmp_str);
	sprintf(check_str,"%d",tmpval);
	if(*tmp_str=='+')
		tmp_str++;
	if(strncasecmp(tmp_str,check_str,strlen(tmp_str))==0)
	{
		*val=tmpval;
		return 0;
	}
	else
	{
		return -1;
	}


}
//convert string to unsigned int
//return :
// 	0,success
// 	-1,failed
static int str2uint(const char *str, //[IN]  the string need to convert
	   unsigned int  *val)//[OUT] convert result
{
	unsigned int  	tmpval;
	char 		*tmp_str=(char *)str;
	char 		check_str[16]={0};
	if(tmp_str==NULL||strlen(tmp_str)<=0||strlen(tmp_str)>11||*tmp_str=='-')
		return -1;
	tmpval=(unsigned int)strtoul(str,NULL,0);
	//tmpval=(unsigned int)atoi(tmp_str);
	sprintf(check_str,"%u",tmpval);
	if(*str=='+')
		tmp_str++;
	if(strncasecmp(tmp_str,check_str,strlen(tmp_str))==0)
	{
		*val=tmpval;
		return 0;
	}
	else
	{
		return -1;
	}


}

//cut off left and right space characters
//include ' ', '\n', '\t', '\r'

static void filter_lr_space(const char *str)
{
	char *ptr1,*ptr2;
	int	len = 0;
	ptr1=ptr2=(char*)str;
	if(str==NULL)
		return;
	while((*ptr2==' ')||(*ptr2=='\n')||(*ptr2=='\t')||(*ptr2=='\r'))
		ptr2++;
	len = strlen(ptr2); //
	if(ptr1 != ptr2)
		//strncpy(ptr1,ptr2,len);
		//strcpy(ptr1,ptr2);
		memmove(ptr1,ptr2,len+1);
//	ptr1[len] = '\0';
	if(!(*ptr1))
		return;
	ptr2=(char*)ptr1+strlen(ptr1)-1;
	while((*ptr2==' ')||(*ptr2=='\n')||(*ptr2=='\t')||(*ptr2=='\r'))
	{
		*ptr2='\0';
		ptr2--;
	}
}


//cut off all space characters
//include ' ', '\n', '\t', '\r'
static void filter_all_space(const char *str)
{
	char *ptr1,*ptr2;
	if(str==NULL)
		return;
	ptr2=ptr1=(char*)str;
	while(*ptr2)
	{
		if ((*ptr2==' ')||(*ptr2=='\t')||(*ptr2=='\r')||(*ptr2=='\n'))
		{
			ptr2++;
			continue;
		}
		*ptr1++=*ptr2++;
	}
	*ptr1='\0';
}


// seek specified section in initialization file,
// file read pointer at beginning of next line
//
// Return:
//	>= 0 : success
//	<  0 : error
static int seek_section(
	FILE *fp,	// [IN] initialization file descriptor
	const char *section)	// [IN] section name in initialization file
{
	char line[MAX_PROF_LINE];
	unsigned int i, j;
	char *pc;

	i = strlen(section);
	while (NULL != fgets(line, MAX_PROF_LINE, fp)) {
		pc = line;

		filter_all_space(pc);
		if(COMMENT_CHAR == *pc)
			continue;
		if (SECTION_PRE != *pc)
			continue;
		pc ++;
		j = strlen(pc);
		if (j < (i + 1) || SECTION_POST != pc[i])
			continue;
		if (strncasecmp(section, pc, i))
			continue;
		return 0;
	}
	return -1;
}



// seek specified key in initialization file
//
// Return:
//	>= 0 : success
//	<  0 : error
static int seek_key(
	FILE *fp,	// [IN] initialization file descriptor
	const char *key,	// [IN] key name in initialization file
	char *line)	// [OUT] key value string
{
	unsigned int i, j;
	char *pc;

	i = strlen(key);
	*line = '\0';
	while (NULL != fgets(line, MAX_PROF_LINE, fp)) {
		pc = line;
//		filter_all_space(pc);
		filter_lr_space(pc);//add by yw 20140811
		if (SECTION_PRE == *pc)	// next section
			return -1;
		if(COMMENT_CHAR == *pc)
			continue;
		j = strlen(pc);
		if (j < i)
			continue;
		if (strncasecmp(key, pc, i))
			continue;
		pc += i;
		filter_lr_space(pc);//add by yw 20140811
		if (VALUE_SET != *pc)
			continue;
		pc++;
		filter_lr_space(pc);//add by yw 20140811
		j = strlen(pc);
//		if (j < 1)
//			return 0;
		memmove(line, pc, j);
		line[j] = '\0';
		return 0;
	}
	return -1;
}

//to get the corresponding value string which decided by section and key
//Return:
//	=0,succuss
//	-1 file is null
//	-2 fopen file failed
//	-3 have no this section
//	-4 have this section, but have no this key
static int get_key_str(const char *file,      //  [IN] initialization file path
	    const char * section,  //	 [IN] section name in initialization file
	    const char* key, 	     //  [IN] keyword name in initialization file
	    char* ret_str)   //	 [OUT] return the string matched to key
{
	FILE* fp;
	if(file==NULL)
		return -1;
	if((fp = fopen(file,"r"))==NULL)
		return -2;

	if (seek_section(fp, section) < 0) {
		fclose(fp);
		return -3;
	}
	if (seek_key(fp, key, ret_str) <0) {
		fclose(fp);
		return -4;
	}
	fclose(fp);
	return 0;
}


//split ip groups
//return:
// 	>=0,success
// 	<0,failed
static int split_ipgroups(
		const char *ipgroups,  // [IN] ipgroups string,eg 10.0.6.201-241
		char*prep_part,  // [OUT] the prep part,eg,10.0.6
		unsigned int *min,// [OUT] eg,201
		unsigned int *max)// [OUT] eg,241
{
	char max_str[4]={0};
	char min_str[4]={0};
	char *temp1=NULL;
	char *temp2=NULL;
	if(ipgroups==NULL||strlen(ipgroups)>19)
		return -1;

	temp1 = strrchr(ipgroups,'.');
	if(temp1==NULL)
		return -1;
	temp1++;
	memcpy(prep_part,ipgroups,(strlen(ipgroups)-strlen(temp1)));
	if(strlen(prep_part)>12)
		return -1;
	temp2=strrchr(temp1,'-');
	if(temp2==NULL)
	{
		if(strlen(temp1)>3)
			return -1;
		else
		{
			memcpy(min_str,temp1,strlen(temp1));
			memcpy(max_str,temp1,strlen(temp1));
		}
	}
	else
	{
		memcpy(min_str,temp1,(strlen(temp1)-strlen(temp2)));
		if(strlen(min_str)>=4)
			return -1;
		temp2++;
		if(strlen(temp2)>=4)
			return -1;
		memcpy(max_str,temp2,strlen(temp2));
	}
	if(str2uint(min_str,min)<0 || str2uint(max_str,max)<0)
		return -1;
	if(*min>*max)
	{
		*min = *min ^ *max;
		*max = *min ^ *max;
		*min = *min ^ *max;
	}

	if(*max>=255||*min>=255||*min<=0)
		return -1;
	return 0;

}

//split uint range
//return:
//  >=0,success,read num
//  <0,failed
static int split_uint_range(
        const char *int_range,  // [IN] int range string,eg 201-241
        unsigned int* out_array,  // [OUT] 201,202,203
        int len)// [OUT] eg,4
{
    char *sign=NULL;
    char temp[10];
    if(out_array==NULL||len<=0)
        return -1;
    memset(temp, 0, sizeof(temp));
    unsigned int start = 0, end = 0;
    sign=strrchr(int_range,'-');
    int real_num = 0, i = 0;
    if(sign != NULL)
    {
	memcpy(temp, int_range, sign-int_range);
    }
    else
	memcpy(temp, int_range, strlen(int_range));
    if(str2uint(temp,&start)<0)
	    return -1;
    if(sign==NULL)
    {
        *out_array = start;
        real_num = 1;
    }
    else
    {
        if(str2uint(sign+1,&end)<0)
            return -1;
        if(end < start)
            return -1;
        for(i = 0; i < (end-start+1); i++)
        {
            out_array[i] = start+i;
            if(i+1 == len || i==(end-start))
                break;
        }
        real_num = i+1;
    }
    return real_num;

}

// get the length of file stream
//Return:
//	>=0 length of file stream
//	<0 failed to get the length becase call fopen failed
static int get_file_stream_len(const char *file)
{
	FILE *fp = NULL;
	int len = 0;
	if((fp = fopen(file,"a+b"))==NULL)
		return -1;
	fseek(fp,0L,SEEK_END);
	len = (int)ftell(fp);
	fclose(fp);
	return len;
}

static void get_update_line(char *line,int line_size,const char *key,const void *val,int type)
{
	memset(line,0,line_size);
	char	*temp = NULL;
	switch(type)
	{
		case TYPE_INT:
			sprintf(line,"%s = %d%s",key,*(int*)val,LINE_BREAK_TAG);
			break;
		case TYPE_FLOAT:
			sprintf(line,"%s = %f%s",key,*(float*)val,LINE_BREAK_TAG);
			break;
		case TYPE_STRING:
			if(strlen(key)+strlen("=")+strlen(LINE_BREAK_TAG)+strlen((char *)val)+sizeof('\0')<(size_t)line_size )
				sprintf(line,"%s=%s%s",key,(char*)val,LINE_BREAK_TAG);
			else
			{
				temp = (char*)malloc(line_size - (strlen(key)+strlen("=")+strlen(LINE_BREAK_TAG)+strlen((char *)val)+sizeof('\0')) + 1);
				memset(temp,0, line_size - (strlen(key)+strlen("=")+strlen(LINE_BREAK_TAG)+strlen((char *)val)+sizeof('\0')) + 1);
				memcpy(temp,val,line_size - (strlen(key)+strlen("=")+strlen(LINE_BREAK_TAG)+strlen((char *)val)+sizeof('\0')));
				sprintf("%s=%s%s",key,temp,LINE_BREAK_TAG);
			}
			free(temp);
			temp = NULL;
			break;
		default:
			break;
	}
}
// Write the value in to specified position of the cofig file,
// Return:
//	>= 0 : length of val
//	  -1 : failed to get the key,may be have no thie section, key or the val which the key pointed error
static int write_profile(
	const char *file,	// [IN] initialization file path
	const char *section,  // [IN] section name in initialization file
	const char *key,   // [IN] keyword name in initialization file
	const void *value,   // [IN] s pointer which point the value need write
	const int value_type) // the type of value
{
	char	*text = NULL;
	char	line[MAX_PROF_LINE] = {0};
	char	tmpline[MAX_PROF_LINE] = {0};
	FILE	*fp = NULL;
	char	*tmp = NULL;
	int	file_len = 0;
	int	line_len = 0;
	int	section_len = strlen(section);
	int	key_len = strlen(key);
	int	section_exist = 0;
	int	cur_text_offset = 0;
	int	finish = 0;//if update the value complete, finish is 1, or is 0
	if(!key) return -1;
	/*get the length of the file stream and alloc enough memory for update file stream*/
	file_len = get_file_stream_len(file);
	if((text = (char *)malloc(file_len + 2*MAX_PROF_LINE+ 1)) == NULL) return -1;
	memset(text, 0 ,file_len + 2*MAX_PROF_LINE + 1);

	/*get new file content, and fill into the memory pointed by text
	 *the new file content have three possibility:
	 *	have no section, add section and key
	 *	have section, but have no key, add key
	 *	have section and key, modify the value
	 */
	if((fp = fopen(file,"rb")) == NULL) {free(text);text=NULL;return -1;}
	tmp = (char *)malloc(MAX_PROF_LINE);
	while(NULL != fgets(line,MAX_PROF_LINE,fp))
	{
		line_len = strlen(line);
		memcpy(tmp,line,line_len+1);
		filter_all_space(tmp);
		if(finish)// content update finished, thr rest of content would be memcpy directly
		{
			memcpy(text + cur_text_offset,line,line_len);
			cur_text_offset += line_len;
			continue;
		}
		if(*tmp == COMMENT_CHAR)// if this line is comment, memcpy directly
		{
			memcpy(text + cur_text_offset,line,line_len);
			cur_text_offset += line_len;
			continue;
		}
		if(*tmp == SECTION_PRE)// this is a section
		{
			if(section_exist == 0)//section is not exist, check this section is equle the section argument
			{
				if(memcmp(tmp+1,section,section_len)==0)
					section_exist = 1;// the section haved be found in this file
			}
			else // the section had be found before, the key is not in this section, so  add it in this section
			{
				get_update_line(tmpline,MAX_PROF_LINE,key,value,value_type);
				memcpy(text+cur_text_offset,tmpline,strlen(tmpline));
				cur_text_offset +=strlen(tmpline);
				finish = 1;
			}
			memcpy(text + cur_text_offset,line,line_len);
			cur_text_offset += line_len;
			continue;
		}
		if(section_exist == 1)// only when section exist, compare the key
		{
			if(memcmp(tmp,key,key_len)==0)// have section and key, modigy the value
			{
				get_update_line(tmpline,MAX_PROF_LINE,key,value,value_type);
				memcpy(text+cur_text_offset,tmpline,strlen(tmpline));
				cur_text_offset +=strlen(tmpline);
				finish = 1;
				continue;
			}
		}
#if 0
		if(memcmp(tmp,key,key_len)==0)
		{
			if(section_exist != 1)
			{
				memcpy(text + cur_text_offset,line,line_len);
				cur_text_offset += line_len;
			}
			else
			{
				get_update_line(tmpline,MAX_PROF_LINE,key,value,value_type);
				memcpy(text+cur_text_offset,tmpline,strlen(tmpline));
				cur_text_offset +=strlen(tmpline);
				finish = 1;
			}
			continue;
		}
#endif

		memcpy(text + cur_text_offset,line,line_len);
		cur_text_offset += line_len;
	}
	free(tmp);
	tmp = NULL;
	fclose(fp);
	/*reached the file end, but no finish, have two possibility:
	 *	hanve no section
	 *	have section, but have no key, and this section must be the last section in this file*/
	if(!finish)
	{
		if(section_exist ==0)//have no section
		{
			/*add section*/
			sprintf(tmpline,"[%s]%s",section,LINE_BREAK_TAG);
			memcpy(text+cur_text_offset,tmpline,strlen(tmpline));
			cur_text_offset +=strlen(tmpline);
		}
		/*add key*/
		get_update_line(tmpline,MAX_PROF_LINE,key,value,value_type);
		memcpy(text+cur_text_offset,tmpline,strlen(tmpline));
		cur_text_offset += strlen(tmpline);
	}
	/*write a new file,the file name is not change*/
	if((fp = fopen(file,"wb"))==NULL)
	{
		free(text);
		text = NULL;
		return -1;
	}
	fwrite(text,cur_text_offset,1,fp);
	fclose(fp);
	free(text);
	text = NULL;
	return 0;
}


// Read in specified integer value
//
// Return:
//	0 : success
//	-1 : failed to get the key,may be have no thie section, key or the val which the key pointed error
//	-2 : error ,the val if out of range
int MESA_load_profile_int_nodef(
	const char *file,	// [IN] initialization file path
	const char *section,	// [IN] section name in initialization file
	const char *key,	// [IN] keyword name in initialization file
	int *val)	// [OUT] returned value
{
	char line[MAX_PROF_LINE] = {0};
//	char *pc;
	if(get_key_str(file,section,key,line)<0)
	{
		return -1;
	}
//	pc = line;
	if(str2int(line,val)<0)
		return -2;
	else
		return 0;
}
// Read in specified integer value
//
// Return:
//	 0 : success
//	<  0 : error, val is set to default
int MESA_load_profile_int_def(
	const char *file,	// [IN] initialization file path
	const char *section,	// [IN] section name in initialization file
	const char *key,	// [IN] keyword name in initialization file
	int *val,	// [OUT] returned value
	const int dval)	// [IN] default value
{
	*val=dval;
	return MESA_load_profile_int_nodef(file,section,key,val);

}


// Read in specified unsigned integer value
//
// Return:
//	0 : success
//	-1 : failed to get the key,may be have no thie section, key or the val which the key pointed error
//	-2 : error ,the val if out of range
int MESA_load_profile_uint_nodef(
	const char *file,	// [IN] initialization file path
	const char *section,	// [IN] section name in initialization file
	const char *key,	// [IN] keyword name in initialization file
	unsigned int *val)	// [OUT] returned value
{
	char line[MAX_PROF_LINE] = {0};
//	char *pc;

	if(get_key_str(file,section,key,line)<0)
	{
		return -1;
	}
//	pc = line;
	if(str2uint(line,val)<0)
		return -2;
	else
		return 0;
}


// Read in specified unsigned integer value
//
// Return:
//	   0 : success
//	<  0 : error, val is set to default
int MESA_load_profile_uint_def(
	const char *file,	// [IN] initialization file path
	const char *section,	// [IN] section name in initialization file
	const char *key,	// [IN] keyword name in initialization file
	unsigned int *val,	// [OUT] returned value
	const unsigned int dval)	// [IN] default value
{
	*val=dval;
	return MESA_load_profile_uint_nodef(file,section,key,val);
}


// Read in specified short integer value
//
// Return:
//	0 : success
//	-1 : failed to get the key,may be have no thie section, key or the val which the key pointed error
//	-2 : error ,the val if out of range
int MESA_load_profile_short_nodef(
	const char *file,	// [IN] initialization file path
	const char *section,	// [IN] section name in initialization file
	const char *key,	// [IN] keyword name in initialization file
	short *val)	// [OUT] returned value
{
	char line[MAX_PROF_LINE] = {0};
//	char *pc;
	int  temp;

	if(get_key_str(file,section,key,line)<0)
	{
		return -1;
	}
//	pc = line;

	if(str2int(line,&temp)<0)
		return -2;
	if(temp>32767||temp<-32768)
		return -2;
	*val=(int)temp;
	return 0;
}



// Read in specified short integer value
//
// Return:
//	   0 : success
//	<  0 : error, val is set to default
int MESA_load_profile_short_def(
	const char *file,	// [IN] initialization file path
	const char *section,	// [IN] section name in initialization file
	const char *key,	// [IN] keyword name in initialization file
	short *val,	// [OUT] returned value
	const short dval)	// [IN] default value
{
	*val=dval;
	return MESA_load_profile_short_nodef(file,section,key,val);
}



// Read in specified string value,
// if value string is too long to return, extra chars truncated.
// prefix/postfix space chars cutted,
// space chars: ' ', '\t', '\r','\n'
//
// Return:
//	>= 0 : length of val
//	  -1 : failed to get the key,may be have no thie section, key or the val which the key pointed error
int MESA_load_profile_string_nodef(
	const char *file,	// [IN] initialization file path
	const char *section,	// [IN] section name in initialization file
	const char *key,	// [IN] keyword name in initialization file
	char *str,	// [OUT] returned string
	const size_t size)	// [IN] buffer size(bytes)
{
	char line[MAX_PROF_LINE] = {0};
	int i;
	char *pc;

	if (0 == size) {
		*str = '\0';
		return 0;
	}

	if(get_key_str(file,section,key,line)<0)
	{
		return -1;
	}
	pc = line;

	i = strlen(pc);
	if( i == 0)
		return 0;
	if (i > size - 1)
		i = size - 1;	// truncate extra chars
	memcpy(str, pc, i);
	str[i] = '\0';
	return i;
}


// Read in specified string value,
// if value string is too long to return, extra chars truncated.
// prefix/postfix space chars cutted,
// space chars: ' ', '\t' '\n' '\r'
//
// Return:
//	>= 0 : length of val
//	<  0 : error, str is set to default
int MESA_load_profile_string_def(
	const char *file,	// [IN] initialization file path
	const char *section,	// [IN] section name in initialization file
	const char *key,	// [IN] keyword name in initialization file
	char *str,	// [OUT] returned string
	const size_t size,	// [IN] buffer size(bytes)
	const char *dstr)	// [IN] default string
{
	int len, t_len;
	if (dstr == NULL)
	{
		*str = '\0';
	}
	else
	{
		t_len = strlen(dstr);
		len = ((size-1)<t_len)?(size-1):t_len;
		memcpy(str, dstr, len);
	}
	return MESA_load_profile_string_nodef(file,section,key,str,size);
}



//read ips from config file
//return :
// 	>=0 : success,return the number of ip read from file successfully
// 	-1  : failed to get the key,may be have no thie section, key or the val which the key pointed error
//	-2  : error,invalid ip
int MESA_load_profile_ipset(
	const char *file,	// [IN] initialization file path
	const char *section,	// [IN] section name in initialization file
	const char *key,	// [IN] keyword name in initialization file
	const size_t size,  // [IN] the number of unit memory ips pointed,a unit ha sizeof(unsigned int) bytes,(it means a unit has 4 bytes),
	unsigned int *ipset) 	// [OUT] return ipset network bytes order
{
	char line[MAX_PROF_LINE];
	char *ip_seg;
	char ip[MAX_IP_SIZE];
	char *saveptr;
	char *pc;
	char prep_part[MAX_IP_SIZE]={0};
	unsigned int  max_ip_suffix;
	unsigned int  min_ip_suffix;
	unsigned int   real_ip_num=0;

	if(get_key_str(file,section,key,line)<0)
		return -1;
	pc = line;
	memset(ipset,0,size);
	while(1)
	{
		ip_seg=strtok_r(pc,";",&saveptr);
		if(ip_seg==NULL)
			break;
		if(split_ipgroups(ip_seg,prep_part,&min_ip_suffix,&max_ip_suffix)<0)
		{
			return -2;
		}
		while(real_ip_num<(unsigned int)size && ((int)max_ip_suffix-(int)min_ip_suffix)>=0)
		{
			memset(ip,0,MAX_IP_SIZE);
			sprintf(ip,"%s%u",prep_part,min_ip_suffix);
			ipset[real_ip_num]=inet_addr(ip);
			min_ip_suffix++;
			real_ip_num++;
		}
		if(real_ip_num==(unsigned int)size)
		{
			break;
		}


		pc=NULL;
	}
	return real_ip_num;
}

//read int range from config file
//return :
//  >=0 : success,return the number of ip read from file successfully
//  -1  : failed to get the key,may be have no thie section, key or the val which the key pointed error
//  -2  : error,invalid int
int MESA_load_profile_uint_range(
    const char *file,   // [IN] initialization file path
    const char *section,    // [IN] section name in initialization file
    const char *key,    // [IN] keyword name in initialization file
    const size_t size,  // [IN] the number of unit memory ips pointed,a unit ha sizeof(unsigned int) bytes,(it means a unit has 4 bytes),
    unsigned int *out)    // [OUT] return ipset network bytes order
{
    char line[MAX_PROF_LINE];
    char *int_seg;
    char *saveptr;
    char *pc;
    unsigned int   real_uint_num=0;

    if(get_key_str(file,section,key,line)<0)
        return -1;
    pc = line;
    memset(out,0,sizeof(int)*size);
    while(1)
    {
        int_seg=strtok_r(pc,",",&saveptr);
        if(int_seg==NULL)
            break;
        int ret = split_uint_range(int_seg,out+real_uint_num,size-real_uint_num);
        if(ret > 0)
            real_uint_num += ret;
        else
            return -1;

        if(real_uint_num==(unsigned int)size)
        {
            break;
        }
        pc=NULL;
    }
    return real_uint_num;
}

// Write the a int into specified position of the config file,the position is decided by section and key
// Return:
//	>= 0 : success
//	  -1 : failed to write profile,maybe fopen failed, or malloc failed
int MESA_write_profile_int(
	const char *file,	// [IN] initialization file path
	const char *section,  // [IN] section name in initialization file
	const char *key,   // [IN] keyword name in initialization file
	const int value    // [IN] the integer need write
)
{
	int temp = value;
	return write_profile(file,section,key,&temp,TYPE_INT);
}

// Write the a float into specified position of the config file,the position is decided by section and key
// Return:
//	>= 0 : success
//	  -1 : failed to write profile,maybe fopen failed, or malloc failed
int MESA_write_profile_float(
	const char *file,	// [IN] initialization file path
	const char *section,  // [IN] section name in initialization file
	const char *key,   // [IN] keyword name in initialization file
	const float value    // [IN] the float need write
)
{
	float temp = value;
	return write_profile(file,section,key,&temp,TYPE_FLOAT);
}
// Write the a string into specified position of the config file,the position is decided by section and key
// Return:
//	>= 0 : success
//	  -1 : failed to write profile,maybe fopen failed, or malloc failed
int MESA_write_profile_string(
	const char *file,	// [IN] initialization file path
	const char *section,  // [IN] section name in initialization file
	const char *key,   // [IN] keyword name in initialization file
	const char *value    // [IN] the string need write
)
{
	const char *temp = value;
	return write_profile(file,section,key,temp,TYPE_STRING);
}
